package com.example.hello_world_services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloWorldServicesApplication.class, args);
	}

}
